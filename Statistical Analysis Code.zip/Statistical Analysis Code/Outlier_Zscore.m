function [inliers_index] = Outlier_Zscore(data,threshold)

% finding outliers by z-score method
mu = mean(data);          % Mean of the data
sigma = std(data);        % Standard deviation of the data
z_scores = (data - mu) / sigma;
inliers_index = (abs(z_scores) < threshold);


end