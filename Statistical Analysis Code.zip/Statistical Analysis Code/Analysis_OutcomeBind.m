% calculating outcome-binding in all trials
%revised 23 Oct 2024

close all
clear all

thershold_60=30;
convert_fact=2560/60;

add='E:\New folder\Document\Master of Science\Thesis\Text\Ahmad\Data\';
names=dir(add);

% per subject 
for i=3:length(names)
    
    % Load data sheet 1
    [S1]=importfile([add names(i).name],'Condition 1');
    ind=isnan(S1.R_actual);
    S1(ind,:)=[];
    S1.perceived_time=double(string(S1.perceive_type));
    S1.perceive_type=S1.AS_played;
    S1.AS_played=[];
    % Load data sheet 2
    [S3]=importfile([add names(i).name],'Condition 3');
    ind=isnan(S3.R_actual);
    S3(ind,:)=[];
    
    % Calculation outcome perception error (positive means perception is later than occurrence)
    % base-line
    ind= strcmp(S1.perceive_type,'STIMULUS') & S1.perceived_time ~= -1;
    base_outcome_err = S1.perceived_time(ind,1) - S1.NS_clock_actual(ind,1);
    base_outcome_err(base_outcome_err < -thershold_60) = base_outcome_err(base_outcome_err < -thershold_60) + 60;
    base_outcome_err(base_outcome_err > thershold_60) = base_outcome_err(base_outcome_err > thershold_60) - 60;
    mean_outcome_base(i-2) = mean(base_outcome_err) * convert_fact;
    
    % operant
    ind= strcmp(S3.perceive_type,'STIMULUS') & S3.perceived_time ~= -1 ;
    cond_outcome_err = S3.perceived_time(ind,1) - S3.NS_clock_actual(ind,1);
    cond_outcome_err(cond_outcome_err < -thershold_60) = cond_outcome_err(cond_outcome_err < -thershold_60) + 60;
    cond_outcome_err(cond_outcome_err > thershold_60) = cond_outcome_err(cond_outcome_err > thershold_60) - 60;
    mean_outcome_cond(i-2) = mean(cond_outcome_err) * convert_fact;

end

% outlayering
out_layer_fact_l = mean(mean_outcome_base)-2*std(mean_outcome_base);
out_layer_fact_h = mean(mean_outcome_base)+2*std(mean_outcome_base);

ind1 = mean_outcome_base > out_layer_fact_l & mean_outcome_base < out_layer_fact_h;

out_layer_fact_l = mean(mean_outcome_cond) - 2*std(mean_outcome_cond);
out_layer_fact_h = mean(mean_outcome_cond) + 2*std(mean_outcome_cond);

ind2 = mean_outcome_cond>out_layer_fact_l & mean_outcome_cond<out_layer_fact_h;

ind = ind1 & ind2;

mean_outcome_cond = mean_outcome_cond(ind);
mean_outcome_base = mean_outcome_base(ind);


%bassline
[~,p_base]=ttest2(zeros(1,length(mean_outcome_base)),mean_outcome_base);

% condition 
[~,p_cond]=ttest2(mean_outcome_cond,zeros(1,length(mean_outcome_base)));

% baseline and condition
[t,p_base_cond]=ttest(mean_outcome_cond,mean_outcome_base);


% bootstrap
outcome_base = zeros(length(mean_outcome_base),1);
outcome_cond = zeros(length(mean_outcome_cond),1);

for i=1:1000
    cue.(['base' num2str(i)]) = [randsample(mean_outcome_base,length(mean_outcome_base), 'true')]';
    cue.(['cond' num2str(i)]) = [randsample(mean_outcome_cond,length(mean_outcome_cond), 'true')]';
    
    outcome_base = outcome_base + cue.(['base' num2str(i)]);
    outcome_cond = outcome_cond + cue.(['cond' num2str(i)]);
    
end

outcome_base = outcome_base/1000;
outcome_cond = outcome_cond/1000;

outcome_shift = outcome_cond - outcome_base;
outcome_shift_median = median(outcome_shift);


% Compute the confidence interval (95% CI)
alpha = 0.05;
lower_bound = prctile(outcome_shift, alpha/2 * 100);  % Lower percentile
upper_bound = prctile(outcome_shift, (1 - alpha/2) * 100);  % Upper percentile

% Display results
% fprintf('Observed Mean Difference: %.4f\n', observed_diff);
fprintf('95%% Confidence Interval: [%.4f, %.4f]\n', lower_bound, upper_bound);

% Check if the confidence interval contains zero
if lower_bound > 0 || upper_bound < 0
    fprintf('The difference is statistically significant.\n');
else
    fprintf('The difference is not statistically significant.\n');
end
