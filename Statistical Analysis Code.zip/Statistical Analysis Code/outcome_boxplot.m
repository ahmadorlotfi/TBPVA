error_data{3} = d3;  % all
event_type = 'Neutral Outcome';

% Concatenate all data into a single column vector
allData = vertcat(error_data{:});

% Create a grouping variable for categories
group = [ones(size(error_data{3}))];

% Specify positions to show each category with two box plots
positions = [ 1.5];

% Create Box Plot
figure
boxH = boxplot(d3, group, 'positions', positions, 'Widths', 0.15, ...
                'Color', 'k', 'MedianStyle', 'line','Symbol','');

% Find all lines in the boxplot and set colors based on position
box_h = findobj(boxH, 'Type', 'Line');
set(box_h, 'Color', [0 0 0],'linewidth',1.5);

% Customize the x-axis to show categories
set(gca, 'XTick', [ 1.5], 'XTickLabel', {'With NS'})
xlabel(event_type)
ylabel('Mean Perceptual Shift (ms)')           
ylim([-149, 199])
xlim([0.75,2.25]);