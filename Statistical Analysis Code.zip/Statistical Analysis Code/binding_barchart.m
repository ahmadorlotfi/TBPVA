function binding_barchart (cue_base, cue_opr, act_base, act_opr, out_base, out_opr)

baselineData = [cue_base, act_base, out_base];
operantData = [cue_opr, act_opr, out_opr];

% Calculate the IQR for each category
baselineIQR = iqr(baselineData);
operantIQR = iqr(operantData);

% Combine data for grouped bar plot
data = [mean(baselineData); mean(operantData)]';  % Use mean values for bars

% Define colors
baselineColor = [1 1 1];    % White for baseline
operantColor = [0.7 0.7 0.7];  % Gray for operant

% Create the bar plot
figure;
b = bar(data, 'grouped','LineWidth',1);

set(gca, 'LineWidth', 1.5);
ax = gca;
ax.XAxis.LineWidth = 1.5;
% Set colors for baseline and operant bars
b(1).FaceColor = baselineColor;
b(2).FaceColor = operantColor;

% Label the x-axis and y-axis
set(gca, 'XTickLabel', {'Cue', 'Action', 'Neutral Outcome'});
xlabel('Evant Type');
ylabel('Mean Perceptual Error (ms)');
%title('Comparison of Baseline and Operant Across Categories');



% % Function to make legend items unclickable
% function [out, varargout] = emptyHit(src, event)
%     out = 'none';
% end
hold on;  % Retain current plot
plot(xlim, [0 0], 'k', 'LineWidth', 1.5);  % Add a black line at y=0 with 1.5 width
hold off;
hold on;
% Add error bars to each bar
for i = 1:3
    % Error bars for baseline
    errorbar(b(1).XData(i) - b(1).BarWidth/5.6, data(i,1), baselineIQR(i)/2, 'k', 'LineStyle', 'none', 'LineWidth', 1, 'CapSize', 10);
    % Error bars for operant
    errorbar(b(2).XData(i) + b(2).BarWidth/5.6, data(i,2), operantIQR(i)/2, 'k', 'LineStyle', 'none', 'LineWidth', 1, 'CapSize', 10);
end

% Set DisplayName for legends
b(1).DisplayName = 'Baseline'; 
b(2).DisplayName = 'Operant';

% Clear automatic legend entries by setting to empty
for k = 1:length(b)
    b(k).DisplayName = ''; % Clear any DisplayName for automatic legend entries
end

% Create custom legend
hLegend = legend([b(1), b(2)], {'Baseline', 'Operant'}, 'Location', 'Best');
hLegend.ItemHitFcn = @emptyHit;  % Disable clicking on legend items
hold off;

% Define position for the significance star above Category 1 bars
% Adjust the vertical position to be slightly above the tallest bar in Category 1
yPos = 380;  % Position star 10% above the tallest bar in Category 1
xPos = 1;  % X position for the first category

% Add significance star
text(xPos, yPos, '*', 'FontSize', 20, 'HorizontalAlignment', 'center', 'Color', 'k');

ylim([-280, 480]);



end