function [bootstrapped_data] = BootStrap (data,round_number)

data_booted = zeros(length(data),1);

for i=1:round_number
    
    sampled_data = [randsample(data, length(data), 'true')]';
    data_booted(:,i) = sampled_data;
        
end

bootstrapped_data = [mean(data_booted)]';
end