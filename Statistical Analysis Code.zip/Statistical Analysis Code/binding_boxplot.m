function binding_boxplot(event_type, d1, d2, d3) 

% Data
error_data{1} = d1;  % without NS
error_data{2} = d2;  % with NS
error_data{3} = d3;  % all
 

% Concatenate all data into a single column vector
allData = vertcat(error_data{:});

% Create a grouping variable for categories
group = [ones(size(error_data{1})); 2*ones(size(error_data{2})); ...
         3*ones(size(error_data{3}))];

% Specify positions to show each category with two box plots
positions = [1, 1.5, 2];

% Create Box Plot
figure
boxH = boxplot(allData, group, 'positions', positions, 'Widths', 0.15, ...
                'Color', 'k', 'MedianStyle', 'line','Symbol','');

% Find all lines in the boxplot and set colors based on position
box_h = findobj(boxH, 'Type', 'Line');
set(box_h, 'Color', [0 0 0],'linewidth',1.5);

% Customize the x-axis to show categories
set(gca, 'XTick', [1, 1.5, 2], 'XTickLabel', {'Without NS', 'With NS', 'All'})
xlabel(event_type)
ylabel('Mean Perceptual Shift (ms)')           
xlim([0.75,2.25]);

end