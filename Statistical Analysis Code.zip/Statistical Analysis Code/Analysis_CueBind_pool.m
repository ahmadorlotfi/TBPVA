function single_binding (event)
% calculating cue-binding in all trials
%revised 23 Oct 2024

close all
clear all

thershold_60=30;
convert_fact=2560/60;

add='E:\New folder\Document\Master of Science\Thesis\Text\Ahmad\Data\';
names=dir(add);

% per subject 
for i=3:length(names)
    
    % Load data sheet 1
    [S1]=importfile([add names(i).name],'Condition 1');
    ind=isnan(S1.R_actual);
    S1(ind,:)=[];
    S1.perceived_time=double(string(S1.perceive_type));
    S1.perceive_type=S1.AS_played;
    S1.AS_played=[];
    % Load data sheet 2
    [S3]=importfile([add names(i).name],'Condition 3');
    ind=isnan(S3.R_actual);
    S3(ind,:)=[];
    
    % Calculation Cue perception error (positive means perception is later than occurrence)
    % base-line
    ind= strcmp(S1.perceive_type,'CUE') & S1.perceived_time ~= -1;
    base_cue_err = S1.perceived_time(ind,1) - S1.C_clock_actual(ind,1);
    base_cue_err(base_cue_err < -thershold_60) = base_cue_err(base_cue_err < -thershold_60) + 60;
    base_cue_err(base_cue_err > thershold_60) = base_cue_err(base_cue_err > thershold_60) - 60;
    mean_base(i-2) = mean(base_cue_err) * convert_fact;
    
    % operant
    ind= strcmp(S3.perceive_type,'CUE') & S3.perceived_time ~= -1 ;
    cond_cue_err = S3.perceived_time(ind,1) - S3.C_clock_actual(ind,1);
    cond_cue_err(cond_cue_err < -thershold_60) = cond_cue_err(cond_cue_err < -thershold_60) + 60;
    cond_cue_err(cond_cue_err > thershold_60) = cond_cue_err(cond_cue_err > thershold_60) - 60;
    mean_cond(i-2) = mean(cond_cue_err) * convert_fact;

end

% outlayering
% out_layer_fact_l = mean(mean_base)-2*std(mean_base);
% out_layer_fact_h = mean(mean_base)+2*std(mean_base);
% ind1 = mean_base > out_layer_fact_l & mean_base < out_layer_fact_h;
% out_layer_fact_l = mean(mean_cond) - 2*std(mean_cond);
% out_layer_fact_h = mean(mean_cond) + 2*std(mean_cond);
% ind2 = mean_cond>out_layer_fact_l & mean_cond<out_layer_fact_h;
% ind = ind1 & ind2;

% check normality of data
figure;
histogram(mean_cond, 10); % 10 bins for the histogram
title('Histogram of Data');
xlabel('Value');
ylabel('Frequency');

[h, p] = kstest(mean_base)

% Step 1: Calculate Q1, Q3 and IQR
Q1 = prctile(mean_base, 25);   % First quartile (25th percentile)
Q3 = prctile(mean_base, 75);   % Third quartile (75th percentile)
IQR = Q3 - Q1;            % Interquartile range

% Step 2: Compute the lower and upper bounds
lower_bound = Q1 - 1.5 * IQR;
upper_bound = Q3 + 1.5 * IQR;

% Step 3: Identify  outliers
ind_cue_base = (mean_base >= lower_bound & mean_base <= upper_bound);

% check normality of data
figure;
histogram(mean_base, 10); % 10 bins for the histogram
title('Histogram of Data');
xlabel('Value');
ylabel('Frequency');

[h, p] = kstest(mean_cond)

% Step 1: Calculate Q1, Q3 and IQR
Q1 = prctile(mean_cond, 25);   % First quartile (25th percentile)
Q3 = prctile(mean_cond, 75);   % Third quartile (75th percentile)
IQR = Q3 - Q1;            % Interquartile range

% Step 2: Compute the lower and upper bounds
lower_bound = Q1 - 1.5 * IQR;
upper_bound = Q3 + 1.5 * IQR;

% Step 3: Identify outliers
ind_cue_cond = (mean_cond >= lower_bound & mean_cond <= upper_bound);

% mu = mean(mean_base);          % Mean of the data
% sigma = std(mean_base);        % Standard deviation of the data
% z_scores = (mean_base - mu) / sigma;
% threshold = 3;
% ind_cue_base = (abs(z_scores) < threshold);
% 
% mu = mean(mean_cond);          % Mean of the data
% sigma = std(mean_cond);        % Standard deviation of the data
% z_scores = (mean_cond - mu) / sigma;
% threshold = 3;
% ind_cue_cond = (abs(z_scores) < threshold);
% 

ind_cue_pool = ind_cue_base & ind_cue_cond;

mean_cond = mean_cond(ind_cue_pool);
mean_base = mean_base(ind_cue_pool);


%bassline
[~,p_base]=ttest2(zeros(1,length(mean_base)),mean_base);

% condition 
[~,p_cond]=ttest2(mean_cond,zeros(1,length(mean_base)));

% baseline and condition
[t,p_base_cond]=ttest(mean_cond,mean_base);


% bootstrap
cue_base = zeros(length(mean_base),1);
cue_cond = zeros(length(mean_cond),1);

for i=1:1000
    cue.(['base' num2str(i)]) = [randsample(mean_base,length(mean_base), 'true')]';
    cue.(['cond' num2str(i)]) = [randsample(mean_cond,length(mean_cond), 'true')]';
    
    cue_base = cue_base + cue.(['base' num2str(i)]);
    cue_cond = cue_cond + cue.(['cond' num2str(i)]);
    
end

cue_base = cue_base/1000;
cue_cond = cue_cond/1000;

cue_shift = cue_cond - cue_base;
cue_shift_median = median(cue_shift);


% Compute the confidence interval (95% CI)
alpha = 0.05;
lower_bound = prctile(cue_shift, alpha/2 * 100);  % Lower percentile
upper_bound = prctile(cue_shift, (1 - alpha/2) * 100);  % Upper percentile

% Display results
% fprintf('Observed Mean Difference: %.4f\n', observed_diff);
fprintf('95%% Confidence Interval: [%.4f, %.4f]\n', lower_bound, upper_bound);

% Check if the confidence interval contains zero
if lower_bound > 0 || upper_bound < 0
    fprintf('The difference is statistically significant.\n');
else
    fprintf('The difference is not statistically significant.\n');
end







% conditional 

% figure
% hold on
% bar(1,mean(mean_cond))
% errorbar(1,mean(mean_cond),std(mean_cond)/sqrt(length(mean_cond)))
% bar(2,mean(mean_base))
% errorbar(2,mean(mean_base),std(mean_base)/sqrt(length(mean_base)))
% set(gca,'Xtick',[1,2],'Xticklabel',{'???????','?? ????'},'tickdir','out')
% title('????? ????? ???? ???? ??')
% ylabel('???? (ms)')
% set(gcf, 'Units', 'cent', 'Position', [0, 0, 6, 6])
% 



