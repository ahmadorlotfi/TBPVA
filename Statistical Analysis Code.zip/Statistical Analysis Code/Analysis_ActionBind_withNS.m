% calculating action-binding in trials with neutral stimulus
%revised 23 Oct 2024

close all
clear all

thershold_60=30;
convert_fact=2560/60;

add='E:\New folder\Document\Master of Science\Thesis\Text\Ahmad\Data\';
names=dir(add);

% per subject 
for i=3:length(names)
    
    % Load data sheet 1
    [S1]=importfile([add names(i).name],'Condition 1');
    ind=isnan(S1.R_actual);
    S1(ind,:)=[];
    S1.perceived_time=double(string(S1.perceive_type));
    S1.perceive_type=S1.AS_played;
    S1.AS_played=[];
    % Load data sheet 2
    [S3]=importfile([add names(i).name],'Condition 3');
    ind=isnan(S3.R_actual);
    S3(ind,:)=[];
    
    % Calculation action perception error (positive means perception is later than occurrence)
    % base-line
    ind= strcmp(S1.perceive_type,'ACTION') & S1.perceived_time ~= -1 & S1.NS_clock_actual ~= -1;
    base_action_err = S1.perceived_time(ind,1) - S1.A_clock_actual(ind,1);
    base_action_err(base_action_err < -thershold_60) = base_action_err(base_action_err < -thershold_60) + 60;
    base_action_err(base_action_err > thershold_60) = base_action_err(base_action_err > thershold_60) - 60;
    mean_action_base(i-2) = mean(base_action_err) * convert_fact;
    
    % operant
    ind= strcmp(S3.perceive_type,'ACTION') & S3.perceived_time ~= -1 & S3.NS_clock_actual ~= -1;
    cond_action_err = S3.perceived_time(ind,1) - S3.A_clock_actual(ind,1);
    cond_action_err(cond_action_err < -thershold_60) = cond_action_err(cond_action_err < -thershold_60) + 60;
    cond_action_err(cond_action_err > thershold_60) = cond_action_err(cond_action_err > thershold_60) - 60;
    mean_action_cond(i-2) = mean(cond_action_err) * convert_fact;

end

% outlayering
out_layer_fact_l = mean(mean_action_base)-2*std(mean_action_base);
out_layer_fact_h = mean(mean_action_base)+2*std(mean_action_base);

ind1 = mean_action_base > out_layer_fact_l & mean_action_base < out_layer_fact_h;

out_layer_fact_l = mean(mean_action_cond) - 2*std(mean_action_cond);
out_layer_fact_h = mean(mean_action_cond) + 2*std(mean_action_cond);

ind2 = mean_action_cond>out_layer_fact_l & mean_action_cond<out_layer_fact_h;

ind = ind1 & ind2;

mean_action_cond = mean_action_cond(ind);
mean_action_base = mean_action_base(ind);


%bassline
[~,p_base]=ttest2(zeros(1,length(mean_action_base)),mean_action_base);

% condition 
[~,p_cond]=ttest2(mean_action_cond,zeros(1,length(mean_action_base)));

% baseline and condition
[t,p_base_cond]=ttest(mean_action_cond,mean_action_base);


% bootstrap
action_NS_base = zeros(length(mean_action_base),1);
action_NS_cond = zeros(length(mean_action_cond),1);

for i=1:1000
    cue.(['base' num2str(i)]) = [randsample(mean_action_base,length(mean_action_base), 'true')]';
    cue.(['cond' num2str(i)]) = [randsample(mean_action_cond,length(mean_action_cond), 'true')]';
    
    action_NS_base = action_NS_base + cue.(['base' num2str(i)]);
    action_NS_cond = action_NS_cond + cue.(['cond' num2str(i)]);
    
end

action_NS_base = action_NS_base/1000;
action_NS_cond = action_NS_cond/1000;

action_NS_shift = action_NS_cond - action_NS_base;
action_NS_shift_median = median(action_NS_shift);


% Compute the confidence interval (95% CI)
alpha = 0.05;
lower_bound = prctile(action_NS_shift, alpha/2 * 100);  % Lower percentile
upper_bound = prctile(action_NS_shift, (1 - alpha/2) * 100);  % Upper percentile

% Display results
% fprintf('Observed Mean Difference: %.4f\n', observed_diff);
fprintf('95%% Confidence Interval: [%.4f, %.4f]\n', lower_bound, upper_bound);

% Check if the confidence interval contains zero
if lower_bound > 0 || upper_bound < 0
    fprintf('The difference is statistically significant.\n');
else
    fprintf('The difference is not statistically significant.\n');
end
