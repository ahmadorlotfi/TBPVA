% All binding Analysis
% Ahmad Lotfi
% 23 Oct 2024
add='E:\New folder\Document\Master of Science\Thesis\Text\Ahmad\Data\';

% Cue-Binding pool
[cue_all_stat, cue_all_data] = single_binding (add, 'CUE', 'ALL');

% Cue-Binding with NS
[cue_NS_stat, cue_NS_data] = single_binding (add, 'CUE', 'NS');

% Cue-Binding without NS
[cue_NONS_stat, cue_NONS_data] = single_binding (add, 'CUE', 'NONS');

% Action-Binding pool
[act_all_stat, act_all_data] = single_binding (add, 'ACTION', 'ALL');

% Action-Binding with NS
[act_NS_stat, act_NS_data] = single_binding (add, 'ACTION', 'NS');

% Action-Binding without NS
[act_NONS_stat, act_NONS_data] = single_binding (add, 'ACTION', 'NONS');

% Outcome-Binding
[out_all_stat, out_all_data] = single_binding (add, 'STIMULUS', 'ALL');

% saving data and stat
SOA.cue_all_data = cue_all_data;
SOA.cue_NS_data = cue_NS_data;
SOA.cue_NONS_data = cue_NONS_data;
SOA.act_all_data = act_all_data;
SOA.act_NS_data = act_NS_data;
SOA.act_NONS_data = act_NONS_data;
SOA.out_all_data = out_all_data;
SOA.cue_all_stat = cue_all_stat;
SOA.cue_NS_stat = cue_NS_stat;
SOA.cue_NONS_stat = cue_NONS_stat;
SOA.act_all_stat = act_all_stat;
SOA.act_NS_stat = act_NS_stat;
SOA.act_NONS_stat = act_NONS_stat;
SOA.out_all_stat = out_all_stat;
save('SOAFile.mat', 'SOA');

%% loading data and stat
load('SOAFile.mat', 'SOA');

%% Figures
% Bar Chart
%binding_barchart (cue_all_data.baseline, cue_all_data.operant, act_all_data.baseline, act_all_data.operant, out_all_data.baseline, out_all_data.operant)
% Box Plots
% cue
d1 = cue_NONS_data.shift_bs;
d2 = cue_NS_data.shift_bs;
d3 = cue_all_data.shift_bs;

binding_boxplot('Cue', d1, d2, d3) 

% action
d1 = act_NONS_data.shift_bs;
d2 = act_NS_data.shift_bs;
d3 = act_all_data.shift_bs;

binding_boxplot('ACTION', d1, d2, d3) 

% outcome

d3 = act_all_data.shift_bs;

binding_boxplot('ACTION', d1, d2, d3) 