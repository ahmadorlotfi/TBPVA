% calculating cue-binding in trials with neutral stimulus 
%revised 23 Oct 2024

close all
clear all

thershold_60=30;
convert_fact=2560/60;

add='E:\New folder\Document\Master of Science\Thesis\Text\Ahmad\Data\';
names=dir(add);

% per subject 
for i=3:length(names)
    
    % Load data sheet 1
    [S1]=importfile([add names(i).name],'Condition 1');
    ind=isnan(S1.R_actual);
    S1(ind,:)=[];
    S1.perceived_time=double(string(S1.perceive_type));
    S1.perceive_type=S1.AS_played;
    S1.AS_played=[];
    % Load data sheet 2
    [S3]=importfile([add names(i).name],'Condition 3');
    ind=isnan(S3.R_actual);
    S3(ind,:)=[];
    
    % Calculation Cue perception error (positive means perception is later than occurrence)
    % base-line
    ind= strcmp(S1.perceive_type,'CUE') & S1.perceived_time ~= -1 & S1.NS_clock_actual ~= -1;
    base_cue_err = S1.perceived_time(ind,1) - S1.C_clock_actual(ind,1);
    base_cue_err(base_cue_err < -thershold_60) = base_cue_err(base_cue_err < -thershold_60) + 60;
    base_cue_err(base_cue_err > thershold_60) = base_cue_err(base_cue_err > thershold_60) - 60;
    mean_NS_base(i-2) = mean(base_cue_err) * convert_fact;
    
    % operant
    ind= strcmp(S3.perceive_type,'CUE') & S3.perceived_time ~= -1 & S3.NS_clock_actual ~= -1;
    cond_cue_err = S3.perceived_time(ind,1) - S3.C_clock_actual(ind,1);
    cond_cue_err(cond_cue_err < -thershold_60) = cond_cue_err(cond_cue_err < -thershold_60) + 60;
    cond_cue_err(cond_cue_err > thershold_60) = cond_cue_err(cond_cue_err > thershold_60) - 60;
    mean_NS_cond(i-2) = mean(cond_cue_err) * convert_fact;

end

% outlayering
% check normality of data
figure;
histogram(mean_NS_base, 10); % 10 bins for the histogram
title('Histogram of Data');
xlabel('Value');
ylabel('Frequency');

[h, p] = kstest(mean_NS_base)

% Step 1: Calculate Q1, Q3 and IQR
Q1 = prctile(mean_NS_base, 25);   % First quartile (25th percentile)
Q3 = prctile(mean_NS_base, 75);   % Third quartile (75th percentile)
IQR = Q3 - Q1;            % Interquartile range

% Step 2: Compute the lower and upper bounds
lower_bound = Q1 - 1.5 * IQR;
upper_bound = Q3 + 1.5 * IQR;

% Step 3: Identify  outliers
ind_cue_base = (mean_NS_base >= lower_bound & mean_NS_base <= upper_bound);

% check normality of data
figure;
histogram(mean_NS_cond, 10); % 10 bins for the histogram
title('Histogram of Data');
xlabel('Value');
ylabel('Frequency');

[h, p] = kstest(mean_NS_cond)

% Step 1: Calculate Q1, Q3 and IQR
Q1 = prctile(mean_NS_cond, 25);   % First quartile (25th percentile)
Q3 = prctile(mean_NS_cond, 75);   % Third quartile (75th percentile)
IQR = Q3 - Q1;            % Interquartile range

% Step 2: Compute the lower and upper bounds
lower_bound = Q1 - 1.5 * IQR;
upper_bound = Q3 + 1.5 * IQR;

% Step 3: Identify outliers
ind_cue_cond = (mean_NS_cond >= lower_bound & mean_NS_cond <= upper_bound);

ind_cue_NS = ind_cue_base & ind_cue_cond;

mean_NS_cond = mean_NS_cond(ind_cue_NS);
mean_NS_base = mean_NS_base(ind_cue_NS);


%bassline
[~,p_base]=ttest2(zeros(1,length(mean_NS_base)),mean_NS_base);

% condition 
[~,p_cond]=ttest2(mean_NS_cond,zeros(1,length(mean_NS_base)));

% baseline and condition
[t,p_base_cond]=ttest(mean_NS_cond,mean_NS_base);


% bootstrap
cue_NS_base = zeros(length(mean_NS_base),1);
cue_NS_cond = zeros(length(mean_NS_cond),1);

for i=1:1000
    cue.(['base' num2str(i)]) = [randsample(mean_NS_base,length(mean_NS_base), 'true')]';
    cue.(['cond' num2str(i)]) = [randsample(mean_NS_cond,length(mean_NS_cond), 'true')]';
    
    cue_NS_base = cue_NS_base + cue.(['base' num2str(i)]);
    cue_NS_cond = cue_NS_cond + cue.(['cond' num2str(i)]);
    
end

cue_NS_base = cue_NS_base/1000;
cue_NS_cond = cue_NS_cond/1000;

cue_NS_shift = cue_NS_cond - cue_NS_base;
cue_NS_shift_median = median(cue_NS_shift);


% Compute the confidence interval (95% CI)
alpha = 0.05;
lower_bound = prctile(cue_NS_shift, alpha/2 * 100);  % Lower percentile
upper_bound = prctile(cue_NS_shift, (1 - alpha/2) * 100);  % Upper percentile

% Display results
% fprintf('Observed Mean Difference: %.4f\n', observed_diff);
fprintf('95%% Confidence Interval: [%.4f, %.4f]\n', lower_bound, upper_bound);

% Check if the confidence interval contains zero
if lower_bound > 0 || upper_bound < 0
    fprintf('The difference is statistically significant.\n');
else
    fprintf('The difference is not statistically significant.\n');
end








% conditional 

% figure
% hold on
% bar(1,mean(mean_cond))
% errorbar(1,mean(mean_cond),std(mean_cond)/sqrt(length(mean_cond)))
% bar(2,mean(mean_base))
% errorbar(2,mean(mean_base),std(mean_base)/sqrt(length(mean_base)))
% set(gca,'Xtick',[1,2],'Xticklabel',{'???????','?? ????'},'tickdir','out')
% title('????? ????? ???? ???? ??')
% ylabel('???? (ms)')
% set(gcf, 'Units', 'cent', 'Position', [0, 0, 6, 6])
% 



