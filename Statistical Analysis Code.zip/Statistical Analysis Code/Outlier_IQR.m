function [inliers_index] = Outlier_IQR (data)
% finding outliers by Interquartile Range Method

% Step 1: Calculate Q1, Q3 and IQR
Q1 = prctile(data, 25);   % First quartile (25th percentile)
Q3 = prctile(data, 75);   % Third quartile (75th percentile)
IQR = Q3 - Q1;            % Interquartile range

% Step 2: Compute the lower and upper bounds
lower_bound = Q1 - 1.5 * IQR;
upper_bound = Q3 + 1.5 * IQR;

% Step 3: Identify outliers
inliers_index = (data >= lower_bound & data <= upper_bound);


end