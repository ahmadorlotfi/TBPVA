
function [a, W_critical] = sw_constants(n)
    % Constants for Shapiro-Wilk test based on sample size
    % INPUT:
    %   n - sample size
    % OUTPUT:
    %   a - coefficients for W statistic calculation
    %   W_critical - critical W value at alpha = 0.05

    % Predefined constants for n <= 50, based on table values for Shapiro-Wilk
    % Normally, this would require more extensive tabulation
    a = -3.65 ./ sqrt(1:n); % Sample coefficient approximation
    W_critical = 0.9; % Critical value approximation for n <= 50
end
