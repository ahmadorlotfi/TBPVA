function binding_boxplot(event_type, d1, d2, d3, d4, d5, d6) 

% Data
error_data{1} = d1;  
error_data{2} = d2;  
error_data{3} = d3;  
error_data{4} = d4;  
error_data{5} = d5;   
error_data{6} = d6;   

% Concatenate all data into a single column vector
allData = vertcat(error_data{:});

% Create a grouping variable for categories
group = [ones(size(error_data{1})); 2*ones(size(error_data{2})); ...
         3*ones(size(error_data{3})); 4*ones(size(error_data{4})); ...
         5*ones(size(error_data{5})); 6*ones(size(error_data{6}))];

% Specify positions to show each category with two box plots
positions = [0.9, 1.1, 1.4, 1.6, 1.9, 2.1];

% Create Box Plot
figure
boxH = boxplot(allData, group, 'positions', positions, 'Widths', 0.1, ...
                'Color', 'w', 'MedianStyle', 'line','Symbol','');


% Hold on to add colored boxes
hold on;

% Get the handles for the boxes
boxHandles = findobj(gca, 'Tag', 'Box');
boxHandles = flipud(boxHandles);  % Ensure boxes are ordered left-to-right

% Define colors for baseline and operant groups
baselineColor = [1 1 1]; % White for baseline
operantColor = [0.8 0.8 0.8]; % Gray for operant

% Loop through box handles and color them
for j = 1:length(boxHandles)
    % Set color based on whether the box is baseline or operant
    if ismember(j, [1, 3, 5]) % Baseline groups
        % Set background to white
        fill(get(boxHandles(j), 'XData'), get(boxHandles(j), 'YData'), baselineColor, 'EdgeColor', 'k', 'LineWidth', 0.5);
    else % Operant groups
        % Set background to gray
        fill(get(boxHandles(j), 'XData'), get(boxHandles(j), 'YData'), operantColor, 'EdgeColor', 'k', 'LineWidth', 0.5);
    end
end


hold on

boxH = boxplot(allData, group, 'positions', positions, 'Widths', 0.1, ...
               'Color', 'w', 'MedianStyle', 'line','Symbol','');
           
% Customize the x-axis to show categories
set(gca, 'XTick', [1, 1.5, 2], 'XTickLabel', {'Without NS', 'With NS', 'All'})
xlabel(event_type)
ylabel('Mean Perceptual Error (ms)')           

% Find all lines in the boxplot and set colors based on position
box_h = findobj(boxH, 'Type', 'Line');
set(box_h, 'Color', [0 0 0],'linewidth',1.5);

% Create a custom legend
legendHandle(1) = rectangle('Position', [0, 0, 1, 1], 'FaceColor', baselineColor, 'EdgeColor', 'k', 'LineWidth', 0.5);
legendHandle(2) = rectangle('Position', [0, 0, 1, 1], 'FaceColor', operantColor, 'EdgeColor', 'k', 'LineWidth', 0.5);

% Use plot with invisible markers to set up legend labels
plotHandle(1) = plot(NaN, NaN, 's', 'MarkerFaceColor', baselineColor, 'MarkerEdgeColor', 'k', 'MarkerSize', 12);
plotHandle(2) = plot(NaN, NaN, 's', 'MarkerFaceColor', operantColor, 'MarkerEdgeColor', 'k', 'MarkerSize', 12);
legend([plotHandle(1), plotHandle(2)], {'Baseline', 'Operant'}, 'Location', 'Best');

hold off
end