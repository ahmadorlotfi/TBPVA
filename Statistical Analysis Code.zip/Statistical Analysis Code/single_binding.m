function [stat, data] = single_binding (add, event, group)
% calculating single bindings
%revised 23 Oct 2024
% group: ALL , NONS, NS

if strcmp(event,'CUE')
    clock_actual_1 = 'S1.C_clock_actual(ind,1)';
    clock_actual_2 = 'S3.C_clock_actual(ind,1)';
    
elseif strcmp(event,'ACTION')
    clock_actual_1 = 'S1.A_clock_actual(ind,1)';
    clock_actual_2 = 'S3.A_clock_actual(ind,1)';
    
elseif strcmp(event,'STIMULUS')
    clock_actual_1 = 'S1.NS_clock_actual(ind,1)';
    clock_actual_2 = 'S3.NS_clock_actual(ind,1)';
end


if strcmp(group,'ALL')
    condition3_1 = 'true';
    condition3_2 = 'true';
    
elseif strcmp(group,'NONS')
    condition3_1 = 'S1.NS_clock_actual == -1';
    condition3_2 = 'S3.NS_clock_actual == -1';
    
elseif strcmp(group,'NS')
    condition3_1 = 'S1.NS_clock_actual ~= -1';
    condition3_2 = 'S3.NS_clock_actual ~= -1';
    
end

thershold_60=30;
convert_fact=2560/60;

names=dir(add);

% per subject 
for i=3:length(names)
    
    % Load data sheet 1
    [S1]=importfile([add names(i).name],'Condition 1');
    ind=isnan(S1.R_actual);
    S1(ind,:)=[];
    S1.perceived_time=double(string(S1.perceive_type));
    S1.perceive_type=S1.AS_played;
    S1.AS_played=[];
    % Load data sheet 2
    [S3]=importfile([add names(i).name],'Condition 3');
    ind=isnan(S3.R_actual);
    S3(ind,:)=[];
    
    % Calculation perception error (positive means perception is later than occurrence)
    % base-line
    ind= strcmp(S1.perceive_type,event) & S1.perceived_time ~= -1 &  eval(condition3_1);
    baseline_err = S1.perceived_time(ind,1) - eval(clock_actual_1);
    baseline_err(baseline_err < -thershold_60) = baseline_err(baseline_err < -thershold_60) + 60;
    baseline_err(baseline_err > thershold_60) = baseline_err(baseline_err > thershold_60) - 60;
    mean_baseline(i-2) = mean(baseline_err) * convert_fact;
    
    % operant
    ind= strcmp(S3.perceive_type,event) & S3.perceived_time ~= -1 & eval(condition3_2);
    operant_err = S3.perceived_time(ind,1) - eval(clock_actual_2);
    operant_err(operant_err < -thershold_60) = operant_err(operant_err < -thershold_60) + 60;
    operant_err(operant_err > thershold_60) = operant_err(operant_err > thershold_60) - 60;
    mean_operant(i-2) = mean(operant_err) * convert_fact;

end
data.baseline = [mean_baseline]';
data.operant = [mean_operant]';

stat.baseline_median = median(data.baseline);
stat.operant_median = median(data.operant);

stat.baseline_IQR = iqr(data.baseline);
stat.operant_IQR = iqr(data.operant);

% outlayering
% check normality of data
% base-line
% [sw_h_baseline, ~, ~] = shapiroWilkTest(mean_baseline);
% 
% % operant
% [sw_h_operant, ~, ~] = shapiroWilkTest(mean_operant);

% % finding doutliers
% % baseline
% if sw_h_baseline == 1 % data is not normally distributed
%     baseline_inlier_ind = Outlier_IQR (mean_baseline);
%     
% elseif sw_h_baseline == 0
%     baseline_inlier_ind = Outlier_Zscore(mean_baseline,3);
% end
% 
% % operant
% if sw_h_operant == 1 % data is not normally distributed
%     operant_inlier_ind = Outlier_IQR (mean_operant);
%     
% elseif sw_h_operant == 0
%     operant_inlier_ind = Outlier_Zscore(mean_operant,3);
% end
% 
% % all
% inlier_ind = baseline_inlier_ind & operant_inlier_ind;
% outlier_ind = ~inlier_ind;
% outliers_num = sum (outlier_ind);
% outliers = find (outlier_ind == 1);
% 
% mean_baseline = mean_baseline(inlier_ind);
% mean_operant = mean_operant(inlier_ind);


% ttest
% [t_value,p_value]=ttest(mean_operant,mean_baseline);

% Ranksum Test
[p_value,signrank_h,s]=signrank(mean_operant,mean_baseline);
 
stat.sr_h = signrank_h;
stat.sr_pval = p_value;
stat.sr_zval = s.zval;

% Extract the z-score from the stats structure
z_score = s.zval;

% Calculate N as the number of non-zero differences
par_num = length(mean_baseline);  % or sum(stats.signedrank > 0) if you exclude zeros

% Calculate the effect size (r)
stat.effect_size_r = z_score / sqrt(par_num);


perception_shift = [mean_operant]'-[mean_baseline]';
% bootstrap
shift_bootstrapped_data = BootStrap (perception_shift,1000);
data.shift_bs = shift_bootstrapped_data;

% calculate shift and median
event_shift = shift_bootstrapped_data;
event_shift_median = median(event_shift);
stat.shift_bs_median = event_shift_median;

% Compute the confidence interval (95% CI)
alpha = 0.05;
lower_bound = prctile(event_shift, alpha/2 * 100);  % Lower percentile
upper_bound = prctile(event_shift, (1 - alpha/2) * 100);  % Upper percentile

% Check if the confidence interval contains zero
if lower_bound > 0 || upper_bound < 0
    %fprintf('The difference is statistically significant.\n');
    bootstrap_v = 1;
else
    %fprintf('The difference is not statistically significant.\n');
    bootstrap_v = 0;
end

stat.bs_h = bootstrap_v;
stat.lower_bound = lower_bound;
stat.upper_bound = upper_bound;
end
