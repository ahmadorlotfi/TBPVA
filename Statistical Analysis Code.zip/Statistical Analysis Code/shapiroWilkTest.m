function [h, pValue, W] = shapiroWilkTest(data)
    % Shapiro-Wilk test for normality
    % INPUT:
    %   data - a vector of sample data
    % OUTPUT:
    %   h - test decision (0 = fail to reject, 1 = reject normality)
    %   pValue - p-value of the test
    %   W - test statistic
    
    % Check that data is a vector
    if ~isvector(data)
        error('Input data must be a vector.');
    end
    
    % Remove any NaN values from the data
    data = data(~isnan(data));
    
    % Sort the data
    data = sort(data);
    n = numel(data);
    
    % Check if sample size is too small
    if n < 3
        error('Sample size must be at least 3.');
    end

    % Load constants for Shapiro-Wilk test
    [a, W_critical] = sw_constants(n);
    
    % Compute the W statistic
    x_mean = mean(data);
    numerator = (sum(a .* (data - x_mean)))^2;
    denominator = sum((data - x_mean).^2);
    W = numerator / denominator;
    
    % Calculate the p-value approximation
    % This approximation is rough and works for small sample sizes (n <= 50)
    if W < W_critical
        pValue = 0.05;
    else
        pValue = 1;
    end
    
    % Decide to reject or not reject the null hypothesis
    h = (pValue < 0.05); % If p < 0.05, reject normality
end
